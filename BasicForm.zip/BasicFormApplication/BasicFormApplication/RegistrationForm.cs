using System.Data.OleDb;

namespace BasicFormApplication
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_users.mdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter da = new OleDbDataAdapter();

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(tbUsername.Text == "" || tbPassword.Text == "" || tbConfirm.Text == "")
            {
                MessageBox.Show("Empty fields, Please Try Again", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUsername.Focus();
            }
            else if(tbPassword.Text != tbConfirm.Text)
            {
                MessageBox.Show("Password doesn't match, Please Try Again", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPassword.Text = "";
                tbConfirm.Text = "";
                tbPassword.Focus();
            }
            else
            {
                try
                {
                    con.Open();
                    string register = "INSERT INTO tbl_users VALUES ('" + tbUsername.Text + "','" + tbPassword.Text + "')";
                    cmd = new OleDbCommand(register, con);
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Successfully created an account!", "Registration Successed", MessageBoxButtons.OK, MessageBoxIcon.None);
                    tbUsername.Text = "";
                    tbPassword.Text = "";
                    tbConfirm.Text = "";

                }
                catch(Exception exc)
                {
                    MessageBox.Show("Something went wrong, Please Try Again", "Registration Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }

            

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbUsername.Text = "";
            tbPassword.Text = "";
            tbConfirm.Text = "";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            LogInForm logInForm = new LogInForm();
            logInForm.Show();
        }

        private void cbPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (cbPassword.Checked)
            {
                tbPassword.PasswordChar = '\0';
                tbConfirm.PasswordChar = '\0';
            }
            else
            {
                tbPassword.PasswordChar = '*';
                tbConfirm.PasswordChar = '*';
            }
        }

        private void lblLogin_Click(object sender, EventArgs e)
        {
            this.Close();
            new LogInForm().Show();
            this.Hide();
        }
    }
}